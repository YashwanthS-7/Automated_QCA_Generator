import re

def yosys_to_lsi(yosys_file, lsi_file):
    with open(yosys_file, 'r') as f:
        lines = f.readlines()
    
    # Initialize LSI structure
    lsi_content = [
        "COMPILE;\n",
        "DIRECTORY MASTER;\n",
        "MODULE DESIGN;\n",
        "INPUTS a, b;\n",
        "OUTPUTS c;\n",
        "LEVEL FUNCTION;\n"
    ]
    
    # Parse Yosys netlist for gates and connections
    for line in lines:
        # Find assign statements (i.e., logic gates and assignments)
        match = re.match(r"\s*assign\s+(\w+)\s*=\s*(.*?);\s*", line)
        if match:
            output = match.group(1)
            logic = match.group(2)

            # Create LSI format for the gate
            if "&" in logic:
                lhs, rhs = logic.split("&")
                lsi_content.append(f"U{len(lsi_content)}({output}=Z) = AND2({lhs}=A, {rhs}=B);\n")
            elif "|" in logic:
                lhs, rhs = logic.split("|")
                lsi_content.append(f"U{len(lsi_content)}({output}=Z) = OR2({lhs}=A, {rhs}=B);\n")
            # Add more logic types (e.g., NOT, XOR) if necessary

    # Finish LSI structure
    lsi_content.append("END MODULE;\n")
    lsi_content.append("END COMPILE;\n")

    # Write to the LSI file
    with open(lsi_file, 'w') as f:
        f.writelines(lsi_content)

yosys_to_lsi("C:\\Users\\yashw\\OneDrive\\Documents\\New folder (2)\\example_netlist.v", "converted_design.lsi")

