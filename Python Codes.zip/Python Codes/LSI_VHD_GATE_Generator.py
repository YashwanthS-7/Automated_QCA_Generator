import re
import os

import re

def generate_lsi(equation, filename="output.lsi"):
    # Identify variables (assumes only uppercase letters are variables)
    inputs = sorted(set(re.findall(r'[A-Z]', equation)))  
    output = "Z"
    intermediate_counter = 1
    gate_lines = []

    try:
        with open(filename, "w") as file:
            # Write header
            file.write("COMPILE;\n")
            file.write("DIRECTORY MASTER;\n")
            file.write("/****** Technology used: qca2 ******/\n")
            file.write(f"MODULE GENERATED_CIRCUIT;\n")

            # Define inputs with A = (A), B = (B), etc.
            for inp in inputs:
                file.write(f"DEFINE {inp} = ({inp});\n")

            file.write(f"OUTPUTS {output};\n\n")
            file.write("LEVEL FUNCTION;\n")
            file.write("DEFINE\n")

            # Process the equation, split it into terms (supporting parenthesis and operators)
            terms = re.findall(r'\([^\)]+\)|[A-Z]+|AND|OR|NOT', equation)
            prev_output = None

            for i, term in enumerate(terms):
                if term == "AND":
                    # Assume previous term and next term are inputs to the AND gate
                    gate_lines.append(
                        f"U{intermediate_counter}(N{i}=Z) = AND2(A={terms[i - 1]},B={terms[i + 1]});"
                    )
                    prev_output = f"N{i}"
                    intermediate_counter += 1
                elif term == "OR":
                    gate_lines.append(
                        f"U{intermediate_counter}(N{i}=Z) = OR2(A={terms[i - 1]},B={terms[i + 1]});"
                    )
                    prev_output = f"N{i}"
                    intermediate_counter += 1
                elif term == "NOT":
                    # Handle NOT gate (single input)
                    gate_lines.append(
                        f"U{intermediate_counter}(N{i}=Z1) = INV(A={terms[i + 1]});"
                    )
                    prev_output = f"N{i}"
                    intermediate_counter += 1
                elif re.match(r'\([^\)]+\)', term):
                    # This is a grouped term (parenthesis), which might need special handling
                    gate_lines.append(
                        f"U{intermediate_counter}(N{i}=Z) = {term};"
                    )
                    prev_output = f"N{i}"
                    intermediate_counter += 1

            # Final assignment to the output if needed
            if prev_output:
                gate_lines.append(f"U{intermediate_counter}({output}=Z) = OR2(A={prev_output},B={prev_output});")

            # Write all gate lines
            for line in gate_lines:
                file.write(f"    {line}\n")

            # Write footer
            file.write("END MODULE;\n")
            file.write("END COMPILE;\n")

        print(f"LSI file written to {filename}")
    except Exception as e:
        print(f"Error writing LSI file: {e}")



def generate_vhd(equation, filename="output.vhd"):
    inputs = sorted(set(re.findall(r'[A-Z]', equation)))  # Identify variables A, B, C, etc.
    output = "OUT"

    try:
        with open(filename, "w") as file:
            file.write("library IEEE;\n")
            file.write("use IEEE.std_logic_1164.all;\n\n")
            file.write(f"entity GENERATED_CIRCUIT is\n")
            file.write("    port (\n")
            file.write(f"        {', '.join([f'{inp}: in STD_LOGIC' for inp in inputs])},\n")
            file.write(f"        {output}: out STD_LOGIC\n")
            file.write("    );\n")
            file.write("end GENERATED_CIRCUIT;\n\n")
            
            file.write("architecture func of GENERATED_CIRCUIT is\n")
            file.write("begin\n")
            
            # Convert equation to VHDL syntax
            equation_vhdl = convert_equation_to_vhdl(equation)
            file.write(f"    {output} <= {equation_vhdl};\n")
            
            file.write("end func;\n")
        print(f"VHDL file written to {filename}")
    except Exception as e:
        print(f"Error writing VHDL file: {e}")


def generate_gate(equation, filename="output.gate"):
    inputs = sorted(set(re.findall(r'[a-zA-Z]', equation)))  # Identify variables a, b, c, etc.
    output = "out"
    intermediate_counter = 10  # Start from n_10 for intermediate nodes
    gate_lines = []

    try:
        with open(filename, "w") as file:
            # Write header
            file.write(".model blif_de_teste\n")
            file.write(f".inputs {' '.join(inputs)}\n")  # Input variables in proper order
            file.write(f".outputs {output}\n")
            file.write(".default_input_arrival 0 0\n")

            # Parse equation for gates
            terms = equation.split()
            prev_output = None

            for i, term in enumerate(terms):
                if term == "AND":
                    gate_lines.append(
                        f".gate AND2 a={terms[i - 1].lower()} b={terms[i + 1].lower()} Z1=n_{intermediate_counter}"
                    )
                    prev_output = f"n_{intermediate_counter}"
                    intermediate_counter += 1
                elif term == "OR":
                    gate_lines.append(
                        f".gate OR2 a={terms[i - 1].lower()} b={terms[i + 1].lower()} Z1=n_{intermediate_counter}"
                    )
                    prev_output = f"n_{intermediate_counter}"
                    intermediate_counter += 1
                elif term == "NOT":
                    gate_lines.append(
                        f".gate INV a={terms[i + 1].lower()} Z1=n_{intermediate_counter}"
                    )
                    prev_output = f"n_{intermediate_counter}"
                    intermediate_counter += 1

            # Connect to the final output
            if prev_output:
                gate_lines.append(f".gate OR2 a={prev_output} b={prev_output} Z1={output}")

            # Write all gate lines
            for line in gate_lines:
                file.write(f"{line}\n")

            # Write footer
            file.write(".end\n")

        print(f"GATE file written to {filename}")
    except Exception as e:
        print(f"Error writing GATE file: {e}")





def convert_equation_to_lsi_steps(equation):
    # Placeholder logic to split equation into LSI steps using OR2, AND2, INV, MAJ3
    # Add proper logic to parse and convert the equation
    steps = [
        "Z1 = OR2(A, B)",  # Example step
        "OUT = INV(Z1)"
    ]
    return steps


def convert_equation_to_vhdl(equation):
    # Replace operators with VHDL syntax
    equation_vhdl = equation.replace("AND", "and").replace("OR", "or").replace("NOT", "not")
    return equation_vhdl


def convert_equation_to_gate_steps(equation):
    # Placeholder logic to split equation into GATE steps using OR2, AND2, INV, MAJ3
    # Add proper logic to parse and convert the equation
    steps = [
        ".gate OR2 a=A b=B Z1=Z1",  # Example step
        ".gate INV a=Z1 Z=OUT"
    ]
    return steps


def main():
    # Ask user for Boolean equation
    equation = input("Enter the Boolean equation (use AND, OR, NOT): ").strip()
    
    # Print the current working directory
    print("Current working directory:", os.getcwd())
    
    # Generate LSI, VHD, and GATE files
    generate_lsi(equation, "generated_circuit.lsi")
    generate_vhd(equation, "generated_circuit.vhd")
    generate_gate(equation, "generated_circuit.gate")
    
    print("LSI, VHD, and GATE files have been generated!")


if __name__ == "__main__":
    main()
